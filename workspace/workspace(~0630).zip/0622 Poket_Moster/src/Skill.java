
public class Skill {
	String name;
	int skillNum;
	int Power;
	
	Skill(int skillNum){
		this.skillNum = skillNum;
		switch (skillNum) {
		case 1 : this.name = "할퀴기";
			this.Power = 40;
			break;
		case 2 : this.name = "몸통박치기";
			this.Power = 40;
			break;
		case 3 : this.name = "바람일으키기";
			this.Power = 40;
			break;
		case 4 : this.name = "전기쇼크";
			this.Power = 40;
			break;
		case 5 : this.name = "불꽃세례";
			this.Power = 40;
			break;
		case 6 : this.name = "물대포";
			this.Power = 40;
			break;
		case 7 : this.name = "덩굴채찍";
			this.Power = 40;
			break;
		}
	}

}
