import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
//		1. Pockemon 클래스를 통하여 mon1 객체 생성
		Pockemon mon1 = new Pockemon("파이리","불꽃" ,43 ,52 ,39);
		Pockemon mon2 = new Pockemon("피카츄", "전기", 40, 55, 35);
		Pockemon mon3 = new Pockemon("꼬부기", "물", 65, 48, 44); 
		
		System.out.println("mon1의 이름 : " + mon1.getName() + ", 타입 : " + mon1.getType());
		System.out.println("mon2의 이름 : " + mon2.getName()+ ", 타입 : " + mon2.getType());
		System.out.println("mon3의 이름 : " + mon3.getName()+ ", 타입 : " + mon3.getType());
		System.out.println();
		
		
		mon2.setType("물");  // 피카츄의 타입을 물로 바꿈
		System.out.println("mon2의 이름 : " + mon2.getName()+ ", 바뀐 타입 : " + mon2.getType());
		mon2.setType("전기");  // 피카츄의 타입을 전기로 돌려줌
		System.out.println("mon2의 이름 : " + mon2.getName()+ ", 돌아온 타입 : " + mon2.getType());
		System.out.println();
		
		
		System.out.println("파이리의 방어력 : " + mon1.getDefense() + ", 공격력 : " + mon1.getAttack() + ", 체력 : " + mon1.getHp());
		System.out.println("피카츄의 방어력 : " + mon2.getDefense() + ", 공격력 : " + mon2.getAttack() + ", 체력 : " + mon2.getHp());
		System.out.println("꼬부기의 방어력 : " + mon3.getDefense() + ", 공격력 : " + mon3.getAttack() + ", 체력 : " + mon3.getHp());
		System.out.println();
		
//		포켓몬을 담을 수 있는 가방 만들기 => 배열사용
		int[] arr = new int[3];
		arr[0] = 1;
		arr[1] = 3;
		arr[2] = 4;
		
		Pockemon[] pocke = new Pockemon[3];
		pocke[0] = mon1;
		pocke[1] = mon2;
		pocke[2] = mon3;
		
		System.out.println("=============================================================");
//		반복문을 활용하여 한번에 포켓몬 정보 가져오기
		for(int i = 0; i< pocke.length; i++) {
			System.out.println("mon" + (i+1) + "의 이름 : " + pocke[i].getName());
			System.out.println("mon" + (i+1) + "의 타입 : " + pocke[i].getType());
			System.out.println("mon" + (i+1) + "의 방어력 : " + pocke[i].getDefense());
			System.out.println("mon" + (i+1) + "의 공격력 : " + pocke[i].getAttack());
			System.out.println("mon" + (i+1) + "의 체력 : " + pocke[i].getHp());
			System.out.println();
		}
		
		System.out.println("=============================================================");
//		가변리스트를 활용하여 사용자가 원하는 타입으로 생성하기
//		1. import 작업 실행해주기
//		2. 어떤 타입으로 가변리스트를 생성할지 타입 지정
		ArrayList <Pockemon> pockeList = new ArrayList<Pockemon>();  // 타입에 Pockemon을 적는다. 여러가지 타입이 섞어있어서
		
		pockeList.add(mon1);
		pockeList.add(mon2);
		pockeList.add(mon3);
		
		for(int i = 0; i< pockeList.size(); i++) {
			System.out.println("mon" + (i+1) + "의 이름 : " + pockeList.get(i).getName());
			System.out.println("mon" + (i+1) + "의 타입 : " + pockeList.get(i).getType());
			System.out.println("mon" + (i+1) + "의 방어력 : " + pockeList.get(i).getDefense());
			System.out.println("mon" + (i+1) + "의 공격력 : " + pockeList.get(i).getAttack());
			System.out.println("mon" + (i+1) + "의 체력 : " + pockeList.get(i).getHp());
			System.out.println();
		}
		
		
	}
}
