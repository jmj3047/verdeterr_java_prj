public class Pockemon {
//	스스로 동작X 설계만 진행하는 클래스 --> main 메소드를 쓰지 않겠다
//	포켓몬 설계도 -> 포켓몬 정보 저장, 기능
//	포켓몬 정보 : 속성(타입) - String, 이름- String, 방어력 - int, 공격력 - int, 체력 - int
	
//	포켓몬 속성 정의
//	private : 접근지정자 제한주기 -> 다른 사용자에 의해서 정보가 수정되지 않도록 하기 위함!
	private String type;
	private String name;
	private int defense;
	private int attack;
	private int hp;
	
//	생성자 메소드
	public Pockemon(String name, String type, int defense, int attack, int hp) {
		this.type = type;
		this.name = name;
		this.defense = defense;
		this.attack = attack;
		this.hp =hp;
	}

	
	
	
//	메소드 get : 속성을 조회
	
	public String getType() {
		return type;
	}

	public String getName() {
		return name;
	}

	public int getDefense() {
		return defense;
	}

	public int getAttack() {
		return attack;
	}

	public int getHp() {
		return hp;
	}


//	메소드 set : 속성을 변경

	public void setType(String type) {
		this.type = type;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setDefense(int defense) {
		this.defense = defense;
	}

	public void setAttack(int attack) {
		this.attack = attack;
	}

	public void setHp(int hp) {
		this.hp = hp;
	}
	

	

	
}
