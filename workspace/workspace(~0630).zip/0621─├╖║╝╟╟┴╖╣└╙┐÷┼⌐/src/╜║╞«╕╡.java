
public class 스트링 {
	public static void main(String[] args) {
		
		String str = "동해물과 백두산이 마르고 닳도록";
		String eng = "Time flows like an arrows";
		if(str.contains("서해물")) {
			System.out.println("들어있음");
		}
		System.out.println(eng.toUpperCase());
		
	}
}
