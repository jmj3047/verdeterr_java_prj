
interface YourType {
    void talk(String msg);
}
