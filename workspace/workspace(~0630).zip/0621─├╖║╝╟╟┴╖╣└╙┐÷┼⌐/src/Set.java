import java.util.HashSet;

//함수 : equals(), hashCode(), removeAll(), contains(값), 
//      remove(값)   add(), size()
public class Set {
	public static void main(String[] args) {
		
		String[] alphabet = {"a", "b", "c", "d", "e", "f", "g", "g", "a"};
		
		HashSet<String> alphabetSet = new HashSet<>();
		HashSet<String> alphabetSet2 = new HashSet<>();
		
        for(String spell: alphabet){
            alphabetSet.add(spell);
            alphabetSet2.add(spell);
        }
        
        alphabetSet.add("z");
        alphabetSet.add("Z");
        alphabetSet.add("X");
        alphabetSet.add("Y");
        alphabetSet.remove("z");
        System.out.println(alphabetSet.hashCode());

        System.out.println(alphabetSet);
        System.out.println(alphabetSet.contains("a"));
        System.out.println(alphabetSet.size());
        System.out.println(alphabetSet.equals(alphabetSet2));
        
	}
}
