import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

//키는 영어단어, 벨류는 한글단어로   맵을 만들고
//단어맞추기 게임 만들어보자.
public class 맵 {
	public static void main(String[] args) {
		
		//1. 맵을 만들기
		HashMap<String, String> dictionary = new HashMap<String, String>();
		//2. 맵에 데이터 넣기
		dictionary.put("apple", "사과");
		dictionary.put("banana", "바나나");
		dictionary.put("melon", "멜론");
		dictionary.put("watermelon", "수박");
		dictionary.put("strawberry", "딸기");
		
		//3. 하나의 키로 제대로된 값 빼올수있나 확인
//		System.out.println(dictionary.get("watermelon"));
		

		
		//5. 랜덤으로 문제 내기
		Random rd = new Random();

		int randomNum = rd.nextInt(dictionary.size());
//		System.out.println("뽑은 랜덤수 : "+randomNum);
		
		//랜덤인덱스에 해당하는 키를 가져와야함
		//키와 벨류로 이루어진 맵이라는 자료구조에 적합하지 않음을 깨달음
		
//		Object[] values = dictionary.values().toArray();  //값리스트. 한글단어
//		Object randomkorWord = values[randomNum];	//랜덤 한글단어
		
		Object[] keys = dictionary.keySet().toArray();	  //키리스트. 영어단어
		String randomEngWord = (String) keys[randomNum];		//랜덤 영단어
		String answer = dictionary.get(randomEngWord);
		System.out.println("다음에 해당하는 한글 단어를 입력해주세요  "+randomEngWord);

		
		//4. 유저에게 입력받기
		Scanner sc = new Scanner(System.in);
		String userKorAnswer = sc.nextLine();
		
		
		//6. 유저의 제출과 정답 비교
		while(!userKorAnswer.equals(answer)) {
			System.out.println("틀렸습니다. 다시입력해주세요");
			userKorAnswer = sc.nextLine();
		}
		System.out.println("정답입니다.");
		
	}
	
}
