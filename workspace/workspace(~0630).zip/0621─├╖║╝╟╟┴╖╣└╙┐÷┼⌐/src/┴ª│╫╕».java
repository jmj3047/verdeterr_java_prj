import java.util.ArrayList;
import java.util.List;

public class 제네릭 {

	//함수의 정의와 호출이 다르다. 파라미터와 아규먼트는 다르다.
	public static void main(String[] args) {
		
		Box<String> strBox = new Box<String>("haha");
		Box<Integer> intBox = new Box<Integer>(5);
		
		String a = strBox.get();
		Integer b = intBox.get();
		System.out.println(a);
		System.out.println(b);
		
		
        People<String,Integer> p1 = new People<String,Integer>("Jack",20);
        //타입 파라미터 추정
        People<String,Integer> p2 = new People("Jack",25);
        //GenericMothod 호출
        boolean result = p1.compare(p1,p2);
        System.out.println(result);
		
		//이때까지는 함수를 정의하든, 클래스를 정의하든 데이터타입을 명시적으로 고정시켜줬었다.
		//하지만 제네릭을 이용하면 '정의할때' 가 아니라 '인스턴스가 만들어질때' 데이터타입이 결정된다. 

		
	}
	
}
