package 계산기;

public class Main {

	public static void main(String[] args) {
		Calculator 계산기 = new Calculator();
		System.out.println(계산기.add(2, 5));
		System.out.println(계산기.minus(-0.5, -0.005));
		System.out.println(계산기.multiple(-2, -5));
		System.out.println(계산기.divide(7, 4));
		
		System.out.println(계산기.add(2.2, 5.5));	//문법에러->오버로드
		System.out.println(계산기.divide(3, 0));
		
		// 나누기가 이상해요.
		// 실수끼리 사칙연산을 할수가 없어요.
			//현재 문법에러. The method add(int, int) in the type Calculator is not applicable for the arguments (double, double)
		// 나누기에서 0을 쓰면 프로그램이 터져요.
			//자바에서 0으로 나누기 하는법 : 잘못된 구글링
			//arithmeticException /by zero가 무엇인지 알고 고치는법 : 좋은 구글링
			//에러로그를	구글링해서 고쳐보기.(구글링 능력)
//			-> 나누는놈을 정수가 아니라 실수형으로 바꿔라.
//			-> if문을 써서 0이면 그냥 넘어가라
//			-> try catch로 예외처리를 해라
		
		System.out.println(계산기.getOnlyQuotient(107, 0));
		System.out.println("안녕");
	}

}
