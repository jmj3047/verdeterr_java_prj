package 계산기;

public class Calculator {

	//add, minus, multiple, divide
	//인자는 2개. 앞의수에서 뒤의수를 사칙연산
	
	public int add(int a, int b) {
		return a+b;
	}
	
	public double add(double a, double b) {
		return a+b;
	}
	
	public int minus(int a, int b) {
		return a-b;
	}
	public double minus(double a, double b) {
		return a-b;
	}
	
	public int multiple(int a, int b) {
		return a*b;
	}
	public double multiple(double a, double b) {
		return a*b;
	}
	
	public float divide(int a, int b) {
		return (float)a/b;
	}
	public double divide(double a, double b) {
		return (double)a/b;
	}
	
	public int getOnlyQuotient(int a, int b) {
		int result=0;
		try {
			result = a/b;	//b가 0이면 이문장을 실행할때 예외가 발생하고 catch로이동
		} catch (Exception e) {
			System.out.println("0으로는 나눌수 없습니다. 다른숫자로 나눠주세요");
			//			e.printStackTrace();//어떤 예외가 발생했는지 로그를 찍어준다.
		}
		System.out.println("getOnlyQuotient 메소드 끝");
		return result;
	}
	public int getOnlyQuotient(double a, double b) {
		return (int) (a/b);
	}
}
