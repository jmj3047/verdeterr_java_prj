package 부동소수점;

import java.math.BigDecimal;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		double total = 0.0;
		
		for (int i=0; i<100; i++) {
			total += 0.1;
		}
		
		System.out.println(total);
		//0.1을 100번 더하기 한 누적값.   10
		
		if(total == 10) {
			System.out.println("블라블라");
		}
		//컴퓨터는 십진수 0.1이라는 값을 '정확하게' 저장할 수 없는 구조다.
		//왜냐하면 부동소수점을 썼기 때문에.
		//그러면 왜 부동소수점을 쓰나요?   
		//정확도를 아주조금 잃은대신에 훨씬 넓은 범위의 값을 표현할 수 있기때문에
		if(Double.compare(total, 10.0)<0){	
			//첫번째인자와 두번째인자를 비교.
			//같으면 0,   첫번째가 크면 양수,   두번째가 크면 음수 반환
			System.out.println("campare로 비교");
		}
		
		//그러면 부동소수점의 연산의 오차를 어떻게 해결할 수 있나요?
		//자바의 부동소수점 데이터타입을 쓰지않고 BigDecimal을 사용
		BigDecimal total2 = new BigDecimal(0.0);
		for (int i=0; i<100; i++) {
			total2 = total2.add(new BigDecimal("0.1")); 
		}
		System.out.println(total2);
		//add, substract, multiply, divide, remainder, compareTo, max, min
	}

}
