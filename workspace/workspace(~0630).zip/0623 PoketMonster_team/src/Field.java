import java.util.Random;
import java.util.Scanner;

public class Field {
	
	
	User usr = new User();
	Scanner sc = new Scanner(System.in);
	Monster[] monster = Monster.nameArr;
	
	

	
	Random rd = new Random();
	//숫자로나옴
	int randomMonster = rd.nextInt(monster.length);
	
	//랜덤한 몬스터 만나기

	
	public void fight() {
		
		
		
	}
	public void getMonster() {
		
		
		
		
	}
	
	

	//필드에 생성된 몬스터 보기

	
	
	
	
}
