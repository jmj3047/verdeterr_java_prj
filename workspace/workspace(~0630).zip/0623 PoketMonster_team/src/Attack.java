import java.util.Random;

public class Attack extends User{
	User usr = new User();
	Monster[] mon = Monster.nameArr;
	Random rd = new Random();
	int randmmonster = rd.nextInt(3);
	// 공격할때의 데미지는 포켓몬의 데미지
	// 공격받을때는 
	//랜덤 포켓몬 생성 

	
	
	

	
	public void usrPoketAttack () {
		
		
		
		
	}
}
