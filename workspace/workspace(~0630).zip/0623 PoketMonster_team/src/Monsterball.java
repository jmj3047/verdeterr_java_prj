
public class Monsterball {

}
