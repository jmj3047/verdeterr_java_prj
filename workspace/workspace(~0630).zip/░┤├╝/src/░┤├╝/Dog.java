package 객체;

public class Dog {
	String name = "바우와우";
	String color = "점박이";
	double weight = 10.5;
	String kind = "달마시안";
	int age = 5;
	
	public void walk() {
		System.out.println("걷습니다.");
	}
	public void run() {
		System.out.println("달립니다.");
	}
	public void jump() {
		System.out.println("점프합니다.");
	}
}
