package 객체;

public class Human {
	String name = "뮤";
	String gender = "여성";
	int age = 3;
	
	public void tame(Cat animal) {
		System.out.println(this.name+"이 "+animal.name+"을 길들입니다.");
	}
	public void tame(Dog animal) {
		System.out.println(this.name+"이 "+animal.name+"을 길들입니다.");
	}
	public void feed() {
		System.out.println("먹이를 주다.");
	}
	public void run() {
		System.out.println("달리다.");
	}
	
	
}
