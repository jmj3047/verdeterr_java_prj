package 객체;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Cat mycat1 = new Cat();
		System.out.println(mycat1.name);
		mycat1.jump();
		
		Human meow=new Human();
		meow.tame(mycat1);
		
		Dog mydog1 = new Dog();
		meow.tame(mydog1);
	}

}
