package 객체;

public class Cat{
	String name = "뮤";
	String color = "검정색";
	double weight = 5.3;
	String kind = "러시안 블루";
	int age = 3;
	
	public void walk() {
		System.out.println("걷습니다.");
	}
	public void run() {
		System.out.println("달립니다.");
	}
	public void jump() {
		System.out.println("점프합니다.");
	}
	
}