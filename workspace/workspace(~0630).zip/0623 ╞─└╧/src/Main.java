import java.io.BufferedWriter;

public class Main {

	public static void main(String[] args) {
//		File file = new File("E:\\java_prj\\0614_0714\\0623파일생성.txt");
//		
//		try {
//			FileWriter fw = new FileWriter(file, true);//파일에 문자열을 입력하기 위한 객체
//			BufferedWriter bufferedWriter = new BufferedWriter(fw);
//			//효율적으로 한번에 쓰기 위한 버퍼 생성
//			
//			if(file.createNewFile()==true) {//파일을 생성. 이미 있다면 else로 
//				System.out.println("파일 생성함");
//			}else {
//				System.out.println("파일 존재함");
//			}
//			String contents = "동해물과 백두산이 마르고 닳도록 하느님이 보우하사 우리나라만세";
//			bufferedWriter.write(contents);
//			bufferedWriter.close();
//			
//		}catch (Exception e) {
//			e.printStackTrace();
//		}
//
	}
}

