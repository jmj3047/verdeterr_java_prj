
public interface 람다인터페이스 {
	public int add(int x, int y);
}
