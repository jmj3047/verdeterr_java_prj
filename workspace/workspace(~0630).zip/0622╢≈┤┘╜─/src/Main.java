
public class Main {

	public static void main(String[] args) {
		//1. 인터페이스만든건 약속만들기
		
		
		//2. 그 약속대로 람다식 구현하기
		//접근제한자 리턴타입 함수명(데이터타입 변수명) { return 값;}
		//					(데이터타입 변수명) { return 값;}
		람다인터페이스 아무이름 = (x,y) -> {return x+y;};
		//(x,y) -> {return x+y;}   이게 람다식(익명함수)이다.
		//그 람다식 전체(이름이 없는 익명함수)가 자동매핑되어 add라는 함수의 본문으로 들어간다.
		
		
		//3. 호출하기
		System.out.println(아무이름.add(20,37));

	}

}
