package 스태틱연습;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Counter c1 = new Counter();
		Counter c2 = new Counter();
		Counter c3 = new Counter();
	}

}
