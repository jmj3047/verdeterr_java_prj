package 로또;

public class Game {
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		Lotto lotto = new Lotto();
//		lotto.makeLotto();

		int rank = 0;
		int buyNum = 5;
		Player p1 = new Player("배성원");
		
		p1.buyLotto(buyNum);
		
		
		int[] winNum = {3,7,12,25,30,33};	//당첨번호


		for(int i=0; i<buyNum; i++) {
			rank = judge(p1.lottoList[i].numArr ,winNum);
			System.out.println(rank+"개 맞음");
		}

	}
	
	public static int judge(int[] challenge, int[] answer) {
		int count = 0;
		for(int i=0; i<challenge.length; i++) {
			for(int j=0; j<challenge.length; j++) {
				if(challenge[i] == answer[j]) {
					count++;
				}
			}
		}
		return count;

	}

}
