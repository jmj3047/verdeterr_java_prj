package 로또;

import java.util.Arrays;
import java.util.Random;

public class Lotto {
	//1부터 45까지 중복없이 6개의 번호
	int [] numArr = new int[6];
	
	
	
	//1. 1부터 45까지의 랜덤 번호 

	//2. 배열에 넣기
	
	//3. 중복이 있으면 다시 뽑기
	
	//4. 오름차순 정렬
	
	public int getRandomNum(int startNum, int endNum) {
		Random rd = new Random();
		int num;
		num = rd.nextInt(endNum)+ startNum;	//알고리즘 이해
		//nextInt(int a) = 0부터 a미만의 랜덤 정수를 리턴한다.
		//거기에 startNum을 더하면 startNum부터 a+startNum미만의 랜덤정수를 리턴.
		//0부터 45미만의 수를 뽑아서  1을 더하니까 1부터 46미만의 수를 얻게되는것
		return num;
	}
	
	public Lotto makeLotto() {
		//1. 리턴이 void에서 Lotto로 바뀜.
		//2. 실체화된 인스턴스를 리턴해야됨.
		//3. int 6개짜리 변수에 랜덤값을 담아 그 Lotto인스턴스를 반환
		//4. this로 바꾸는게 더 좋음
		
		int [] newNumberList = new int[6];
		for(int i=0; i<6; i++) {
			int randomNum = getRandomNum(1, 45);
			boolean isdup = findDup(newNumberList, randomNum); //넣기전에 중복된것이 있나 검사
			if(isdup == true) {	//중복이 있다면
				//System.out.printf("%d%s %s %d \n", i+1,"번째 숫자 뽑을때 중복 발생.", "  값 : ",randomNum  );
				randomNum = getRandomNum(1, 45);	//새로뽑기
				//System.out.println("새로뽑은값 : "+ randomNum);
				i--;	//다시뽑은것이 중복일때를 대비하여 방금뽑은걸 다시 검사
			}else {
				newNumberList[i] = randomNum;	//새로뽑은 숫자 현재 자리에 넣기
			}
			
		}
		sort(newNumberList);
		this.numArr = newNumberList;
		return this;
	}
	
	//기존의 배열의 값에서 중복된것이 있나 검사
	public boolean findDup(int[] arr, int targatNum) {
		for(int i=0; i<arr.length; i++) {
			if(arr[i] == targatNum) {
				return true;
			}
		}
		return false;
	}

	public void sort(int[] arr) {
		Arrays.sort(arr);
	}
	
	
	@Override
	public String toString() {
		return "Lotto [num=" + Arrays.toString(numArr) + "]";
	}
	
	
}
