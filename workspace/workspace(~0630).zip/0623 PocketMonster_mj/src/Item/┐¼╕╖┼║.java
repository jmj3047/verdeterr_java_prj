package Item;

public class 연막탄 extends Item {

    public 연막탄(String name, int power){
    	this.name = name;
    	setPower(power);
    }
}
