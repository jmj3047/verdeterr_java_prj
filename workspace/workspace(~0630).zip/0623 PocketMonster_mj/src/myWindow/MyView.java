package myWindow;

import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JDesktopPane;
import javax.swing.JProgressBar;

import Player.Player;
import Poketmon.Poketmon;

import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class MyView {

	Player p;
	Poketmon other;
	Poketmon mine;
	int myAttackPower;
	int otherAttackPower;
	public static boolean whooseWin;
	public static boolean end;


	public MyView(Player p, Poketmon other, Poketmon mine, int myAttackPower, int otherAttackPower) {
//		this();
		this.p = p;
		this.other = other;
		this.mine = mine;
		this.myAttackPower = myAttackPower;
		this.otherAttackPower = otherAttackPower;
		
		
		while(other.gethp() >= 0 || mine.gethp() >= 0 ) {
			mine.attackbyPoketmon(other, otherAttackPower);
			System.out.println(mine.name + "이(가) " + other.name + "님을 공격했습니다! ! !\n");
			mine.show();
			other.show();
			other.attackbyPoketmon(mine, otherAttackPower);
			System.out.println(other.name + "이(가)" + mine.name + "님을 공격했습니다! ! !\n");
			mine.show();
			other.show();
			
			if(other.gethp() <= 0) {
				whooseWin = true;
				end = true;
				other.sethp(30); //hp 초기화 
				mine.sethp(30); //hp 초기화 
				break;
			}
			
			if(mine.gethp() <= 0) {
				whooseWin = false;
				end = true;
				other.sethp(30); //hp 초기화 
				mine.sethp(30); //hp 초기화
				break;
			}
			
		}
//		System.out.println(mine.name + "이(가) " + other.name + "님을 공격했습니다! ! !\n");
//		mine.show();
//		other.show();
//		mine.attackbyPoketmon(other, otherAttackPower);
//		mine.show();
//		other.show();
//		mine.attackbyPoketmon(other, otherAttackPower);
//		mine.show();
//		other.show();
//		mine.attackbyPoketmon(other, otherAttackPower);
//		mine.show();
//		other.show();
//		mine.attackbyPoketmon(other, otherAttackPower);
//		mine.show();
//		other.show();
//		mine.attackbyPoketmon(other, otherAttackPower);
//		mine.show();
//		other.show();
//		mine.attackbyPoketmon(other, otherAttackPower);
//		mine.show();
//		other.show();
//		mine.attackbyPoketmon(other, otherAttackPower);
//		mine.show();
//		other.show();
//		mine.attackbyPoketmon(other, otherAttackPower);
//		mine.show();
//		other.show();
//		mine.attackbyPoketmon(other, otherAttackPower);
//		mine.show();
//		other.show();
//		mine.attackbyPoketmon(other, otherAttackPower);
//		
//		
//		if(other.gethp() <= 0) {
//			whooseWin = true;
//			end = true;
//			other.sethp(30); //hp 초기화 
//			mine.sethp(30); //hp 초기화 
//		}
//		
//		System.out.println(other.name + "이(가)" + mine.name + "님을 공격했습니다! ! !\n");
//		if(mine.gethp() <= 0) {
//			whooseWin = false;
//			end = true;
//			other.sethp(30); //hp 초기화 
//			mine.sethp(30); //hp 초기화 
//		}else end=true;
//		
//		
		
				
//		playerName.setText("Player : " + p.name);
//		playerPoketmonName.setText("포켓몬 : " + mine.name);
//		targetName.setText("포켓몬 : " + other.name);
//		
//		
//		progressBar_target.setValue(mine.gethp());
//		progressBar_me.setValue(other.gethp());
		
//		playerAttackButton.addActionListener(new ActionListener() { //player의 공격 
//			public void actionPerformed(ActionEvent e) {
//				
//				mine.attackbyPoketmon(other, myAttackPower);
//				
//				mine.show();
//				other.show();
//				
//				//글자쓰는거 추가해야함!! 오늘 수업 내용 
//				System.out.println(mine.name + "이 " + other.name + "님을 공격했습니다! ! !\n");
//				
//				if(other.gethp() <= 0) {
//					whooseWin = true;
//					end = true;
//					other.sethp(30); //hp 초기화 
//					mine.sethp(30); //hp 초기화 
//				}
//			}
//		});
//		
//		targetAttackButton.addActionListener(new ActionListener() { //target의 공격 
//			public void actionPerformed(ActionEvent e) {
//				
//				other.attackbyPoketmon(mine, otherAttackPower);
//				progressBar_me.setValue(mine.gethp());
//				
//				other.show();
//				mine.show();
//				
//				//글자쓰는거 추가해야함 !! 오늘 수업 내용 
//				textArea.append(other.name + "이 " + mine.name + "님을 공격했습니다! ! !\n");
//				
//				if(mine.gethp() <= 0) {
//					playerAttackButton.setEnabled(false);
//					targetAttackButton.setEnabled(false);
//					whooseWin = false;
//					end = true;
//					other.sethp(30); //hp 초기화 
//					mine.sethp(30); //hp 초기화 
//					frame.dispose(); //대결 화면 종료 
//				}
//				
//				
//			}
//		});
		
		
	
	}
}
