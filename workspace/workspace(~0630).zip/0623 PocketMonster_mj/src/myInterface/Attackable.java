package myInterface;

import Item.Item;
import Poketmon.Poketmon;
import Weapon.Weapon;

public interface Attackable {

    public abstract void attack();
}
