package PoketMonster;

public class 눈덩이 extends Item {

    public 눈덩이(String name, int power){
    	this.name = name;
    	setPower(power);
    }
}
