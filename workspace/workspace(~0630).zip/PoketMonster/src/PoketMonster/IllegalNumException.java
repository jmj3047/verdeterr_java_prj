package PoketMonster;

public class IllegalNumException extends Exception { //java.lang.Exception 이어서 따로 import 안해도됨!
	
	public IllegalNumException() { super(); } //생성자 
	
}
