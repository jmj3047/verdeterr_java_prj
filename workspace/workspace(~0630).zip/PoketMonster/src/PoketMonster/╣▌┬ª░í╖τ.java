package PoketMonster;

public class 반짝가루 extends Item {

    public 반짝가루(String name, int power){
    	this.name = name;
    	setPower(power);
    }

}
