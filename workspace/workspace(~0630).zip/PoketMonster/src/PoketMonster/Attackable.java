package PoketMonster;

import Item;
import Poketmon;
import Weapon;

public interface Attackable {

    public abstract void attack();
}
