package PoketMonster



;

public class ZeroException extends Exception {

	public ZeroException() {} //생성자 
	
	public String getMessage() {
		return "K.O !!!";
	}
	
}
