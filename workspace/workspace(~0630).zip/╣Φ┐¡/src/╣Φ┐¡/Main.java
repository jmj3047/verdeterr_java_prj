package 배열;

import java.util.Arrays;

public class Main {
	
	public static void main(String[] args) {
		//선언, 정의, 초기화:선언이나 정의 후에 값을 할당해주는 작업까지 한번에 하는 거 
		int[] intArr = {1,2,3,4,5,6,7,8,9,10}; //초기화
		int[] intArr3;
//		int Arr = {12,3,4,5,65,6,7,7,};
		System.out.println(intArr.length);
		System.out.println(intArr[9]);
//		intArr[10]=11;
//		System.out.println(intArr[10]);
//		intArr = {1,2,3,4,5};
		intArr3 = new int[] {1,2,3,4,5,6,7,8,9,10}; //자바형식
		
		if (intArr == intArr3) {//배열은 원시형데이터 타입이 아니기 때문에 주소를 참조함.
			System.out.println("같음");
		}
		
//		String strArr1 = {"일","이","삼"};
		//에러남: cannot convert from String[] to String
		//스트링배열을 스트링으로 변환할 수 없습니다.
		
		int twoMention [][] = {{1,2,3},{5,10,15}};
		System.out.println(twoMention.length);
		System.out.println(twoMention[1]);
		//향상된 for 문. iterator=반복할 수 있는 객체
		//iterator의 모든 요소에 대해서 반복을 수행
		for(int i: twoMention[1]) {
			System.out.println(i+" ");
		}
		
		int [][][] threeDemension = new int[2][4][6];
		//6개 짜리가 4개 있고 그런 놈이 2개 있다.
		System.out.println(threeDemension.length);
		
		String [] season = {"spring","summer","삼"};
		String [] 복사본 = season; //배열의 복사. 그냥 =으로 하면 얕은 복사
		String [] 진짜복사본;
		String [] 진짜복사본2;
		진짜복사본2 = null;
		boolean result = Arrays.asList(season).contains("winter");
		System.out.println(result);
		
		//배열의 복사. 그냥 =으로 하면 얕은 복사.
		
		if(season == 복사본) {
			System.out.println("같다");
		}else {
			System.out.println("틀리다");
		}
		
		진짜복사본 = season.clone();
		if(season == 진짜복사본) {
			System.out.println("같다");
		}else {
			System.out.println("틀리다");
		}
		//깊은 복사를 하기 위해서 반복문을 돌리든가, System.arraycopy() 메소드를 이용
		System.arraycopy(season, 0, 진짜복사본2, 0, season.length);
		
		
	}
}
