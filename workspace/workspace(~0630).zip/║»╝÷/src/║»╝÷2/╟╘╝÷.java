package 변수2;

public class 함수 {

//	  접근제한자 리턴타입 메소드명(인자타입 인자명, 인자타입 인자명...){
//		    함수본문;
//		    리턴타입 void가 아닐경우 리턴문;
//		  }
	
	public void printDan(int dan) {
		for(int i=1; i<=9; i++) {
			System.out.printf("%d * %d = %d", dan, i, dan*i);
			System.out.println(dan + " * " + i + " = " + dan*i);
		}
	}
	
	//인풋x  아웃풋x	
	//인풋x  아웃풋o
	//인풋o  아웃풋x	//printDan(int dan)
	//인풋o  아웃풋o
	
	public void helloWorld() { //인풋x  아웃풋x	
		System.out.println("hello");
		System.out.println("world");
	}
	
	public String cry() {
		return "엉엉";
	}
	
	public String cry2(String name) {
		String result = "";
		switch(name){
			case "tiger":
				result = "어흥";
				break;
			case "dolphine":
				result = "삐이이익";
				break;
			case "monkey":
				result = "우끼끼";
				break;
		}
		return result;
	}
	
}
