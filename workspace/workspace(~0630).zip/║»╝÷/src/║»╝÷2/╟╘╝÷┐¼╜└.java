package 변수2;

public class 함수연습 {
	//1. 2개의 정수를 입력받아 합친수를 리턴하는 함수 add를 만들어보세요.
	public int add(int num1, int num2) {
		return num1+num2;
	}
	
	//2. 2개의 정수를 입력받아 앞의 수에서 뒤의 수를 뺀수를 리턴하는 함수 minus를 만들어보세요.
	public int minus(int num1, int num2) {
		return num1-num2;
	}
	
	
	//3. 2번문제를 큰수에서 작은수를 빼도록 업그레이드 해보세요
	public int minus2(int num1, int num2) {
		if(num1>num2) {
			return num1-num2;
		}else {
			return num2-num1;
		}
	}
	
	//4. 세개의 수를 입력하면 그중에서 가장 큰수를 리턴하는 함수 getMaxNum를 만들어보세요.
	public int getMaxNum(int num1, int num2, int num3) {
		//힌트 : 최대값을 가지고있을 변수 하나 선언
		int max = num1;
		if(max < num2) {
			max = num2;
		}
		if(max < num3) {
			max = num3;
		}
		return max;
	}
	
	//5. 정수 하나를 인자로 받는 isOverHundred라는 함수를 만들기.
		//100을 초과하면 true, 100이하면 false를 리턴
	public boolean isOverHundred(int num) {
		if(num>100) {
			return true;
		}else {
			return false;
		}
	}
	
	//	6. 1부터 100까지의 정수중에 짝수만 콘솔로 찍어보세요.
	public void printEven() {
		for(int i=1; i<=100; i++) {
			if(i%2 == 0) {
				System.out.println(i);
			}
		}
	}
	
	
	// 7. 1부터 100까지의 정수중에 3의 배수만 콘솔로 찍어보세요.
	public void printThreeMul() {
		for(int i=1; i<=100; i++) {
			if(i%3 == 0) {
				System.out.println(i);
			}
		}
	}
	
	//8. 1부터 100까지 정수를 순회하면서 5의 배수만 찍어보세요. 단, 그중에 10의 배수는 찍지마세요.
	public void printOnlyFiveMul() {
		for(int i=1; i<=100; i++) {
			if(i%5 == 0 && !(i%10==0)) {
				System.out.println(i);
			}
		}
	}
	
	//9. 첫번째인자로 문자열, 두번째인자로 양수를 받아 문자열을 숫자의 횟수만큼 출력해보세요.
	//만약 음수를 입력했을경우 잘못된 값을 입력했다고 알려주고 아무처리도 하지마세요.
	public void printStrLoop(String str, int count) {
		if(count<0) {
			return;
		}
		for (int i=0; i<count; i++) {
			System.out.println(str);
		}
	}
	
	//10.
	//	달을 입력받아 해당달이 어느 계절인지 리턴하는 함수 getSeason
	//	3,4,5 : 봄
	//	6,7,8 : 여름
	//	9,10,11 : 가을
	//	12, 1, 2 : 겨울
	public String  getSeason(int month) {
		int quotient = (int)(month / 3);
		switch (quotient) {
		case 1:
			return "봄";
		case 2:
			return "여름";
		case 3:
			return "가을";
		default:
			return "겨울";
		}
	}
	
	
	//11.
	//	스트링 2개를 입력받아 첫번째 문자열안에 두번째문자열이 포함되어있는지 판단하는 함수
	//	isInclude 만들어보세요.
	//배우지않은것을 키워드를 선정해서 구글링한다음 해결해보세요.
	public boolean isInclude(String mother, String son) {
		if(mother.contains(son)) {
			return true;
		}
		else {
			return false;
		}
	}
	
	//12. 스트링2개를 입력받아 첫번째 문자열안에 두번째문자열이 몇개 포함되어있는지 리턴
	////찾으면 해당 위치를 기록하고 카운트++
	////해당위치 그다음문자열 부터 다시 검색
	////이런방식으로 문자열의 끝까지 검색
	////끝까지 검색되었다면 이때까지 찾은 카운트 반환
//	public int getCountInclude(String mother, String son) {
//		int count = 0;
//		int start = mother.indexOf(son);
//		System.out.println("start :" +start);
//		count++;
//		int start2 = mother.indexOf(mother[start]);
//		System.out.println("start2 :" +start2);
//
//		return count;
//
//
//	}
	
	
	  //강지원
	  public int getCountInclude(String str1, String str2){
	      boolean include = true;
	      int count = 0;
	      include = str1.contains(str2);	//포함되었는지 참거짓 판단
	      while(include) {	//포함되었다면
	         count++;
	         int where = str1.indexOf(str2);	//시작하는 위치 파악
	         str1 = str1.substring(where+str2.length());
	         System.out.println("str1 : "+str1);
	         //방금찾은거를 빼고 남은 문자열을 부모로 업데이트
	         //substring 함수는 인자가 하나면 해당위치부터 이후로 끝까지 자르는 함수
	         include = str1.contains(str2);
	      }
	      return count;
	   }
	  
	  
	  //정진우
	  public int howManyString(String a, String b) {
	      int count = 0;
	      int i = 0;
	      
	      while (a.length() > 0) {
	         if (a.indexOf(b) > -1) {
	            i = a.indexOf(b);
	            count++;
	         }else {
	            break;
	         }
	         a = a.substring(i+b.length());
	      }
	      
	      return count;
	   }
	  
	  
	  //한정인
	  public int getCountInclude2(String mother, String son) {
			int count = 0;
			char mother1[] = mother.toCharArray();
			char son1[] = son.toCharArray();
			for(int i = 0; i < son.length(); i++){
				for(int j = 0; j < mother.length(); j++) {
					if(son1[i] == mother1[j])
						count++;
				}
			}
			
			return count;
		}

	  
	 
}
