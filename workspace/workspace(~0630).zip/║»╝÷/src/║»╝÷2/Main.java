package 변수2;
//import java.util.Arrays;
public class Main {

	public static void main(String[] args) {
		
//		int a = 5;
//		double b = 7.5;
//		
//		System.out.println(a+b);
//		
//		
//		//call by value. 기본형. 값에의한 참조
//		char x = 'a';
//		String y = "hello";
//		System.out.println(x+y);
//		
//		int myNum = a;
//		myNum = myNum +10;
//		System.out.println("myNum : "+ myNum);
//		System.out.println("a : "+ a);
//		
//	
//		//call by reference. 참조형. 주소에의한 참조
//		String[] imgArr = {"🍕","🍖"};
//		String[] stringArr = {"피자", "통닭",""};
//		imgArr = stringArr;	//한글이 들어감
//		stringArr[2] = "아이스크림";	//2번째배열을 건드렸는데
//		for(int i=0; i<imgArr.length; i++) {
//			System.out.println(imgArr[i]);	//1번째배열이 변했다
//		}
//		
		함수연습 fn1 = new 함수연습();
//		System.out.println(fn1.add(3, 80));
//		System.out.println(fn1.minus2(30, 40));
//		System.out.println(fn1.minus2(3, -4));
//		System.out.println(fn1.minus2(7, 7));
//		int result = fn1.getMaxNum(20, -720, -355);
//		System.out.println(fn1.isOverHundred(result));
//		fn1.printEven();
//		fn1.printOnlyFiveMul();
//		fn1.printStrLoop("동해물과 백두산이", -45);
//		System.out.println(fn1.getSeason(1));
//		System.out.println(fn1.isInclude("백두산 한라산 에베레스산", "한라산"));
		System.out.println(fn1.getCountInclude2("백두산 백두산2 백두산3 한라산 에베레스산", "백두산"));
//		백두산 백두산2 백두산3 한라산 에베레스산
//		 백두산2 백두산3 한라산 에베레스산
//		2 백두산3 한라산 에베레스산
	}

}
