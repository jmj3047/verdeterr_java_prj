package 변수;

public class 함수불러오기 {

	public static void main(String[] args) {
		함수연습 fn1=new 함수연습();
//	    System.out.println(fn1.minus2(200, 300));
//		fn1.printFiveMul();
//		fn1.printString("안녕", 3);
//		fn1.printString("안녕", -3);
//		fn1.getSeason(4);
//		fn1.isInclude("hello he he", "he");
		fn1.isIncludeMany("hello he he", 'l');
		System.out.println(fn1.getCountInclude("엄태현엄태현엄태현엄태현", "엄"));

	}

}
