package 변수;

public class Main {
	public static void main(String[] args) {
//		System.out.println("Hello world");
		
		int a = 5;
		double b = 7.5;
		System.out.println(a+b);
		
		
		//call by value. 기본형. 값에 의한 참조
		char x = 'a';
		String y = "Hello";
		System.out.println(x+y);
		
		int myNum = a;
		myNum = myNum + 10;
		System.out.println(myNum);
		System.out.println(a);
		
		
		
		//call by reference. 참조형. 주소에 의한 참조를 함
		String[] arr1 = {"pizza","chicken"};
		String[] arr2 = {"피자","통닭"," "};
		arr1 = arr2; //한글이 들어감
		arr2[2] = "파스타"; //두번째 배열을 건드렸는데 
		for(int i=0; i<arr1.length;i++) {
			System.out.println(arr1[i]); //첫번째 배열이 변했다
		}
		
		
	}

}
