//import org.apache.commons.lang.StringUtils;
//import static org.junit.Assert.assertEquals;
package 변수;


public class 함수연습 {
	//1. 2개의 정수를 입력받아 합친수를 리턴하는 함수 add를 만들어보세요
	public int add(int a, int b) {
		return a+b;
	}
	
	//2. 2개의 정수를 입력받아 앞의 수에서 뒤의 수를 뺸수를 리턴하는 함수 minus를 만들어보세요
	public int minus(int a, int b) {
		return a-b;
	}
	
	//3. 2번문제를 큰수에서 작은수를 판별해서 빼도록 업그레이드 해보세요.
	public int minus2(int a, int b) {
		if(a>b) {
			return a-b;
		}else {
			return b-a;
		}
	
	}
	//4. 세개의 수를 입력하면 그중에서 가장 큰 수를 리턴하는 getMaxNum을 만들어보세요
	public int getMaxNum(int a, int b, int c) {
		if (a>b && a>c){
			return a;
		}else if (b>a && b>c) {
			return b;
		}else {
			return c;
		}
		
	}
	//5. 정수하나를 인자로 받는 isOverHundred라는 함수 만들기
		//100을 초과하면 true, 100이하면 false를 리턴
	public boolean isOverHundred(int a) {
		if (a>100){
			return true;
		}else  {
			return false;
		}
		
	}
	
	//6. 1부터 100까지의 정수중에 짝수만 콘솔로 찍어보세요.
	public void printEven() {
		for(int i = 1;i<=100;i++) {
			if(i%2==0) {
				System.out.println(i);
			}
		}
	}
	
	//7. 1부터 100까지의 정수중에 3의 배수만 콘솔로 찍어보세요.
	public void printThreeMul() {
		for(int i = 1;i<=100;i++) {
			if(i%3==0) {
				System.out.println(i);
			}
		}
	}
	
	//8. 1부터 100까지 정수를 순회하면서 5의 배수만 찍어보세요. 단 10의 배수는찍지 마세요
	public void printFiveMul() {
		for(int i = 1;i<=100;i++) {
			if(i%5==0 && i%10!=0) {
				System.out.println(i);
			}
		}
	}
	
	//9. 첫번째 인자로 문자열, 두번째 인자로 숫자를 받아 문자열을 숫자의 횟수만큼 출력해보세요
	//만약 음수를 입력했을때는 잘못된 값을 입력했다고 알려주고 아무처리도 하지 마세요
	public void printString(String string, int b) {
		if(b>=0) {
			for(int i = 1;i<=b;i++) {
				System.out.println(string);
				}
		}else {
			System.out.println("잘못입력하셨습니다.");
		}
	}

	
	//10.
//	달을 입력받아 해당 달이 어느 계절인지 리턴 하는 함수 getSeason을 만들어 보세요.
//	3,4,5:봄
//	6,7,8:여름
//	9,10,11:가을
//	12,1,2:겨울
	public void getSeason(int b) {
		if(b==3 || b==4 || b==5) {
			System.out.println("봄");
		}if(b==6 || b==7 || b==8) {
			System.out.println("여름");
		}if(b==9 || b==10 || b==11) {
			System.out.println("가을");
		}if(b==12 || b==1 || b==2) {
			System.out.println("겨울");
		}
	}
	public String getSeason2(int b) {
		int value =(int)(b / 3);
		switch (value) {
		case 1:
			return "봄";
		case 2:
			return "여름";
		case 3:
			return "가울";
		default:
			return "겨울";
		}
	}
	
	
	
	//11. 인자 2개를 입력받아 첫번째 문자열 안에 두번째 문자열이 포함되어 있는지 판단하는 함수 isInclude 만들어보세요. 
	//배우지 않은 것을 키워드를 선정해서 구글링 한다음 해결해 보세요
	 public void isInclude(String a, String b) {
		 System.out.println(a.contains(b));
	 }
	
	//12. 스트링 2개를 입력받아 첫번쨰 문자열 안에 두번쨰 단어가 몇개 포함되어 있는지 리턴
	 public void isIncludeMany(String a, char b) {
			int count = 0;
			 
			for (int i = 0; i < a.length(); i++) {
			    if (a.charAt(i) == b) {
			        count++;
			    }
			}
			System.out.println(count);
			
			 
		 }

	 public int getCountInclude(String str1, String str2){
	      boolean include = true;
	      int count = 0;
	      include = str1.contains(str2); //포함되었는지 참거짓 판단
	      while(include) { //포함되었다면
	         count++;
	         int where = str1.indexOf(str2); //시작하는 위치 파악
	         str1 = str1.substring(where+str2.length());
	         include = str1.contains(str2);
	      }
	      return count;
	   }
	 
	 //13. 인자로 들어온 글자가 100글자 이하면 허용해주고 100글자 넘으면 허용하지 않을 용도로 쓸 함수를 작성해주세요. 
	 public boolean isOver100(String input) {
		 if(input.length()>100) {
			 return false;
		 }else {
			 return true;
		 }
		
	 }
	//14. 기준을 인자로 받아 고정되지 않고 변할수 있도록 업그레이드 해주세요.
	 public boolean isOver(String input, int cri) {
		 if(input.length()>100) {
			 return false;
		 }else {
			 return true;
		 }
	 }
	
	
}


	

