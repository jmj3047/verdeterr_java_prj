
public class Player {
	//name, hp, mana, damage
	//attack, skill1, skill2
	String name;
	int hp = 100;
	int mana = 100;
	int damage = 10;
	
	
	public Player(String name) {
		//this가 자기자신이고 super는 부모다.
		//super(); //있으나 없으나 큰 차이 없음. 부모의 기본 생성자를 호출한거다. 
		this.name = name;
	}
	
	
	public void attack(Slime enemy) {
		//죽으면 죽었다고 알려주기
		//죽은놈에게는 공격 못하기
				
		if(enemy.hp<=0) {
			System.out.println(enemy.name+"은 이미 죽은 상태라 공격할 수 없습니다.\n");
			return;
		}
		int afterhp = enemy.hp - this.damage;
		System.out.printf("%s의 체력이 %d에서 %d가 되었습니다.\n", enemy.name, enemy.hp, afterhp);
		if(afterhp<=0) {//적이 죽은경우
			afterhp = 0;
			System.out.println("적이 죽었습니다.");
			enemy.hp = afterhp;
			return;
		}
		System.out.printf("%s가 %s를 %d의 데미지로 공격합니다.\n", this.name, enemy.name, this.damage);
		enemy.hp = afterhp;
		
		
	}
	public void setWeapon(Weapon weapon) {
		System.out.printf("%s가 %s를 장착하겠습니다. 데미지 %d증가 \n", this.name, weapon.name, weapon.damage);
		this.damage += weapon.damage;
	}
}
