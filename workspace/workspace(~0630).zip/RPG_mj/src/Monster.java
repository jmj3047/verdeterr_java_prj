
public class Monster {
	String name;
	int hp;
	int mana;
	int damage;
	String kind;
	
	public Monster(String name,int hp2) {
		this.name = name;
		this.hp = hp2;
	}


	public void attack(Player player) {
		if(player.hp<=0){
			System.out.println(player.name+"은 이미 죽은 상태라 공격할 수 없습니다.\n");
			return;
		}
		int afterhp = player.hp - this.damage;
		System.out.printf("%s의 체력이 %d에서 %d가 되었습니다.\n", player.name, player.hp, afterhp);
		if(afterhp<=0) {//적이 죽은경우
			afterhp = 0;
			System.out.println("적이 죽었습니다.");
			player.hp = afterhp;
			return;
		}
		System.out.printf("%s가 %s를 %d의 데미지로 공격합니다.\n", this.name, player.name, this.damage);
		player.hp = afterhp;
	}
}
