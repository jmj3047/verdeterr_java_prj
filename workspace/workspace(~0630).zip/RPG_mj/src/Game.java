
public class Game {

	public static void main(String[] args) {
		Player player1 = new Player("J");
		Slime enemy1 = new Slime("빨간 슬라임", 100);
		player1.attack(enemy1);
//		player1.attack(enemy1);
//		player1.attack(enemy1);
//		player1.attack(enemy1);
		//무기를 하나 만들어서 그 무기를 장착하면 해당 무기의 데미지 만큼 플레이어의 데미지를 올려주세요
		Weapon weapon1 = new Weapon();
		weapon1.name = "S";
		weapon1.damage = 20;
		Weapon weapon2 = new Weapon();
		weapon2.name = "H";
		weapon2.damage = 35;
		
//		Slime enemy2 = new Slime();
//		player1.setWeapon(weapon2);
//		player1.attack(enemy2);
		
		Potion healPotion = new Potion("healingPotion(s)", 30, "red", "recovery");
		System.out.println(healPotion.name);
		Potion forcementPotion = new Potion("forcement(s)");
		System.out.println(forcementPotion.name);
		
		Golem gol1 = new Golem("골렘", 1000);
		gol1.defenceOn();
	}

}
