
public class Slime extends Monster {
	//name, hp, damage
	//attack, skill1
	public Slime(String name, int hp) {
	      super(name, hp);
	      
	   }
}
