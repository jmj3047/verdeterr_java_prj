
public class Weapon {
	String name;
	int damage;
}
