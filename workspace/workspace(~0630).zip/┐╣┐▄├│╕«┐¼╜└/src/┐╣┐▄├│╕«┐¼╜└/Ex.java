package 예외처리연습;

public class Ex {
	int[] arr = {1,2,3,4,5};
	
	public void printAllElement() {
		for(int i=0; i<arr.length; i++) {
			System.out.println(arr[i]);
		}
	}
	
	public void printOneElement(int index) {
		//예외처리하고 정상범위 알려주기
		try {
			System.out.println(arr[index]);
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("해당위치는 범위를 넘어섰습니다. "+arr.length+"까지 입력해주세요.");
		} finally {
			System.out.println("finally 실행");
		}
		System.out.println("printOneElement 끝");
		
	}
}
