package 예외처리연습;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ex ex1 = new Ex();
//		ex1.printAllElement();
		ex1.printOneElement(8);
		System.out.println("정상실행되고있음");
	}

}
