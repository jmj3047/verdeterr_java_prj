# import sys
# import time

# print ("HELLO" + sys.argv[1])

# def testprint(a):
#     a = sys.argv[1]
#     # print(a)

#     return a

# print(testprint(sys.argv[1]))
# -*- coding: utf-8 -*-
import sys
import csv
import traceback

def main():
    try:
        print("hello world before")
        import pandas as pd
        print('import success')
        # data_dir = './MBTI_dataset/
        train = pd.read_csv('./MBTI_dataset/MBTI_train.csv', encoding='ISO 8859-1', header=None, names=['type', 'posts'])
        print("df success")
        # with open('./MBTI_dataset/csvtest.csv', 'r', encoding='ISO 8859-1') as csvfile:
        #     train = csv.reader(csvfile, delimiter=' ', quotechar='|')
        #     for row in train:
        #         print(', '.join(row))
            # train = csv.reader('./MBTI_dataset/MBTI_train.csv', encoding='ISO 8859-1')
            # print(train)
            
        print("after the dataframe")
    except:
        print("예외발생")
        traceback.print_stack()
    
print(sys.argv[1])
main()
