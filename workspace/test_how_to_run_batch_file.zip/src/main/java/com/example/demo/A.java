package com.example.demo;

public class A {

	public static void main(String[] args) {
		B b = new B();
		b.setA(11);
		System.out.println(b.getA());
		
		b.click();

	}

}
