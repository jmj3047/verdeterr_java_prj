import sys
import time

print ("HELLO" + sys.argv[1])

