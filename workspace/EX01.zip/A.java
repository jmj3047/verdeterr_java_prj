package test01.EX01;

public class A {

	public static void main(String[] args) {
		B b = new B();
		b.setA(11);
		System.out.println(b.getA());
		
		b.click();

	}

}
