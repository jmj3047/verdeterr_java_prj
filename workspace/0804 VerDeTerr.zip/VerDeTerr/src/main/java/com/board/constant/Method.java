package com.board.constant;
// Enum은 상수를 처리하는 목적으로 사용되는 클래스입니다. 
public enum Method {

	GET,POST,PUT,PATCH,DELETE
}
